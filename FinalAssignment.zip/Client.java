 /*
 * Peter Nguyen
 * Final Assignment
 * November 2023
 * SE 320 ERAU
 */

package finalAssignment;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Client extends JFrame implements ActionListener {
 // Text field for receiving value
private JTextField tfw = new JTextField(); // weight kilograms
private JTextField tfh = new JTextField(); // height meters

// Text area to display contents
private JTextArea jta = new JTextArea();

// IO streams
private DataOutputStream outputToServer;
private DataInputStream inputFromServer;

public static void main(String[] args) {
    new Client();
}

public Client() {
     // Panel p to hold the label and text field
    JPanel p = new JPanel();
    p.setLayout(new BorderLayout());
    p.add(new JLabel("Enter weight"), BorderLayout.WEST);
    p.add(tfw, BorderLayout.CENTER);

    JPanel p2 = new JPanel();
    p2.setLayout(new BorderLayout());
    p2.add(new JLabel("Enter height"), BorderLayout.WEST);
    p2.add(tfh, BorderLayout.CENTER);
    
    tfw.setHorizontalAlignment(JTextField.RIGHT);
    tfh.setHorizontalAlignment(JTextField.RIGHT);
    
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(p, BorderLayout.NORTH);
    getContentPane().add(p2, BorderLayout.SOUTH);
    getContentPane().add(new JScrollPane(jta), BorderLayout.CENTER);

    tfw.addActionListener(this); // Register listener
    tfh.addActionListener(this); // Register listener
    
    setTitle("Client");
    setSize(500, 300);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true); // It is necessary to show the frame here!
    
    try {
         // Create a socket to connect to the server
        Socket socket = new Socket("localhost", 8000);
         // Socket socket = new Socket("130.254.204.36", 8000);
         // Socket socket = new Socket("drake.Armstrong.edu", 8000);
        
         // Create an input stream to receive data from the server
        inputFromServer = new DataInputStream(
        socket.getInputStream());
        
         // Create an output stream to send data to the server
        outputToServer =
        new DataOutputStream(socket.getOutputStream());
    }
    catch (IOException ex) {
        jta.append(ex.toString() + '\n');
    }
}

public void actionPerformed(ActionEvent e) {
    String actionCommand = e.getActionCommand();
    if (e.getSource() instanceof JTextField) {
        try {
             // Get the weight height from the text field
            double weight = Double.parseDouble(tfw.getText().trim());
            double height = Double.parseDouble(tfh.getText().trim());
            
             // Send the radius to the server
            outputToServer.writeDouble(weight);
            outputToServer.writeDouble(height);
            outputToServer.flush();
            
             // Get area from the server
            double bmi = inputFromServer.readDouble();
            
             // Display to the text area
            jta.append("Weight: "+weight+" Height: "+height+"\n");
            jta.append("BMI from server: "
            +bmi+'\n');
        }
        catch (IOException ex) {
            System.err.println(ex);
        }
    }
}
}