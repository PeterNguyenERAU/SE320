/******************************************************************************
Peter Nguyen

Assignment 5
November 2023
SE 320 ERAU

1. Write a program that computes the number of 
days that have elapsed since you were born.
Use the Day class we studied in class, not 
the GregorianCalendar class. 
You can find all three implementations of the Day class 
(that we've seen in class) on Canvas, under
Modules>Supplementary Material.

2. Write a precondition or requires clause for the method removeDuplicates, so all duplicates
from List lst are removed.
*******************************************************************************/

package A4;
import java.util.*;

public class Assignment5 {

	public static void main(String[] args) {
		System.out.println("Days from today since birthday");
		int birthYear = 2003;
		int birthMonth = 1;
		int birthDay = 3;
		int currentYear = 2023;
		int currentMonth = 11;
		int currentDay = 22;
		
		Day birthDate = new Day(birthYear, birthMonth, birthDay);
		Day today = new Day(currentYear, currentMonth, currentDay);
		System.out.println(today.daysFrom(birthDate));
	}
	
	/**
	* Removes duplicates in list.
	* requires: a list such that every element with duplicates 
	* is adjacent to at least one other identical element
	*/
	public static void removeDuplicates(List lst) {
		if (lst == null || lst.size() == 0) 
			return;
		List copy = new ArrayList(lst);
		Iterator elements = copy.iterator();
		Object pre = elements.next();
		while(elements.hasNext()) {
			Object nex = elements.next();
			if (pre.equals(nex)) 	lst.remove(nex);
			else 			pre = nex;
		}
	}
}
